extends Node2D
## BOUNCE BACK PINBALL (simple edition)  -  hackathon theme: "Bouncing Back"
## One rule: lose a ball and every ball after it scores DOUBLE.
## Reach the target score to clear a table. 3 tables.
## Everything (art, physics, sound) is generated in code. Made for Godot 4.2+.

# ------------------------------------------------------------------ constants
const W := 1280.0
const H := 720.0
const OFF := Vector2(390.0, 10.0)   # where the table sits on screen
const TH := 700.0                   # table height
const LANE_X := 455.0               # wall that separates the plunger lane
const BALL_R := 10.0
const GRAV := 1000.0
const MAX_SPEED := 2200.0
const SUBSTEPS := 6
const FLIP_LEN := 78.0
const REST_A := 0.5                 # flipper resting angle (pointing down)
const UP_A := -0.52                 # flipper raised angle

enum State { MENU, PLAYING, LEVEL_DONE, FAILED, WIN }

# ------------------------------------------------------------------ data
class Bumper:
	var pos := Vector2.ZERO
	var r := 28.0
	var pulse := 0.0

class Flip:
	var pivot := Vector2.ZERO
	var side := 1            # -1 = left flipper, +1 = right flipper
	var a := 0.5
	var da := 0.0
	var down := false
	func dir() -> Vector2:
		if side < 0:
			return Vector2(cos(a), sin(a))
		return Vector2(-cos(a), sin(a))
	func ddir() -> Vector2:
		if side < 0:
			return Vector2(-sin(a), cos(a))
		return Vector2(sin(a), cos(a))

# Each table: target score + bumpers as [x, y, radius]. Edit freely!
var LEVELS: Array = [
	{
		"name": "Table 1", "target": 1500,
		"bumpers": [[227, 230, 30], [150, 320, 28], [305, 320, 28]],
		"color": Color("ff4d9d"), "bg": Color("1a1030"),
	},
	{
		"name": "Table 2", "target": 3000,
		"bumpers": [[227, 190, 30], [135, 285, 27], [320, 285, 27], [227, 380, 28]],
		"color": Color("ffb703"), "bg": Color("0f1f3a"),
	},
	{
		"name": "Table 3", "target": 4500,
		"bumpers": [[227, 260, 30], [130, 330, 26], [325, 330, 26], [95, 190, 24], [360, 190, 24]],
		"color": Color("5ee08a"), "bg": Color("0f2a22"),
	},
]

# ------------------------------------------------------------------ game state
var state: int = State.MENU
var level_idx := 0
var t := 0.0
var score := 0
var balls_left := 3
var comeback := false
var launched := false
var charge := 0.0
var space_lock := false
var stuck_t := 0.0
var win_pending := false

var ball_p := Vector2.ZERO
var ball_v := Vector2.ZERO

var segs: Array = []
var arc_pts := PackedVector2Array()
var bumpers: Array = []
var flips: Array = []

var toast_text := ""
var toast_t := 0.0

var sfx_players := {}
var muted := false
var font: Font    # calligraphy font, picked from whatever the player's system has


# =================================================================== setup
func _ready() -> void:
	var sf := SystemFont.new()
	sf.font_names = PackedStringArray([
		"Lucida Calligraphy", "Apple Chancery", "Zapfino", "Snell Roundhand",
		"Brush Script MT", "Segoe Script", "URW Chancery L", "Z003", "cursive"])
	sf.allow_system_fallback = true
	font = sf
	for i in range(0, 41):
		var a := PI + PI * float(i) / 40.0
		arc_pts.append(Vector2(250.0 + 250.0 * cos(a), 250.0 + 250.0 * sin(a)))
	setup_audio()
	build_table(0)
	reset_ball()
	state = State.MENU


func build_table(idx: int) -> void:
	var cfg: Dictionary = LEVELS[idx]
	segs.clear()
	bumpers.clear()
	flips.clear()

	# walls: [from, to, bounciness]
	for i in range(1, arc_pts.size()):
		segs.append([arc_pts[i - 1], arc_pts[i], 0.35])
	segs.append([Vector2(0, 250), Vector2(0, 530), 0.4])                    # left wall
	segs.append([Vector2(500, 250), Vector2(500, 660), 0.2])                # right wall
	segs.append([Vector2(LANE_X, 215), Vector2(LANE_X, 660), 0.4])          # lane divider
	segs.append([Vector2(LANE_X, 660), Vector2(500, 660), 0.1])             # plunger floor
	segs.append([Vector2(0, 530), Vector2(130, 607), 0.3])                  # left guide
	segs.append([Vector2(LANE_X, 530), Vector2(325, 607), 0.3])             # right guide

	for d in cfg["bumpers"]:
		var b := Bumper.new()
		b.pos = Vector2(float(d[0]), float(d[1]))
		b.r = float(d[2])
		bumpers.append(b)

	var fl := Flip.new()
	fl.pivot = Vector2(137, 610)
	fl.side = -1
	fl.a = REST_A
	flips.append(fl)
	var fr := Flip.new()
	fr.pivot = Vector2(318, 610)
	fr.side = 1
	fr.a = REST_A
	flips.append(fr)


func reset_ball() -> void:
	ball_p = Vector2(477.5, 649.0)
	ball_v = Vector2.ZERO
	launched = false
	charge = 0.0
	stuck_t = 0.0


func start_level(idx: int) -> void:
	level_idx = idx
	build_table(idx)
	score = 0
	balls_left = 3
	comeback = false
	win_pending = false
	toast_t = 0.0
	space_lock = true
	reset_ball()
	state = State.PLAYING
	show_toast("Hold SPACE, then release")


func go_menu() -> void:
	level_idx = 0
	build_table(0)
	reset_ball()
	state = State.MENU


# =================================================================== input
func _input(event: InputEvent) -> void:
	var confirm := false
	if event is InputEventKey and event.pressed and not event.echo:
		var k: int = event.keycode
		if k == KEY_SPACE or k == KEY_ENTER or k == KEY_KP_ENTER:
			if state != State.PLAYING:
				confirm = true
		elif k == KEY_R and state == State.PLAYING:
			start_level(level_idx)
		elif k == KEY_ESCAPE and state != State.MENU:
			go_menu()
		elif k == KEY_M:
			muted = not muted
			AudioServer.set_bus_mute(0, muted)
	if confirm:
		on_confirm()


func on_confirm() -> void:
	if state == State.MENU:
		start_level(0)
	elif state == State.LEVEL_DONE:
		if level_idx + 1 >= LEVELS.size():
			state = State.WIN
		else:
			start_level(level_idx + 1)
	elif state == State.FAILED:
		start_level(level_idx)
	elif state == State.WIN:
		go_menu()


func can_launch() -> bool:
	return ball_p.x > LANE_X and ball_p.y > 600.0 and ball_v.length() < 150.0


# =================================================================== update
func _process(delta: float) -> void:
	var dt := minf(delta, 1.0 / 30.0)
	t += dt
	toast_t = maxf(0.0, toast_t - dt)

	if state == State.PLAYING:
		update_controls(dt)
		var sdt := dt / float(SUBSTEPS)
		for i in SUBSTEPS:
			step_physics(sdt)
		for item in bumpers:
			var b: Bumper = item
			b.pulse = maxf(0.0, b.pulse - dt * 4.0)
		update_rules(dt)
	queue_redraw()


func update_controls(dt: float) -> void:
	var l := Input.is_physical_key_pressed(KEY_LEFT) or Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_Z)
	var r := Input.is_physical_key_pressed(KEY_RIGHT) or Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_SLASH)
	var raw_launch := Input.is_physical_key_pressed(KEY_SPACE) or Input.is_physical_key_pressed(KEY_DOWN)
	var launch_in := raw_launch

	if space_lock:
		if not raw_launch:
			space_lock = false
		launch_in = false

	for item in flips:
		var f: Flip = item
		var want := l if f.side < 0 else r
		if want and not f.down:
			play_sfx("flip")
		f.down = want

	if can_launch():
		if launch_in:
			charge = minf(1.0, charge + dt / 0.8)
		elif charge > 0.03:
			do_launch()
	else:
		charge = 0.0


func do_launch() -> void:
	ball_v = Vector2(0.0, -(1350.0 + 600.0 * charge))
	charge = 0.0
	launched = true
	stuck_t = 0.0
	play_sfx("launch")


func update_rules(dt: float) -> void:
	# rescue a ball that has stopped somewhere silly
	if ball_v.length() < 25.0 and not can_launch():
		stuck_t += dt
		if stuck_t > 2.0:
			stuck_t = 0.0
			ball_v = Vector2(randf_range(-250.0, 250.0), -420.0)
	else:
		stuck_t = 0.0

	if win_pending:
		win_pending = false
		state = State.LEVEL_DONE
		play_sfx("win")
		return

	if ball_p.y > TH + 30.0:
		on_drain()


func on_drain() -> void:
	balls_left -= 1
	play_sfx("hurt")
	if balls_left <= 0:
		state = State.FAILED
		return
	comeback = true
	show_toast("Bounce back! Scores x2 now")
	reset_ball()


func add_score(pts: int) -> void:
	if state != State.PLAYING:
		return
	score += pts * (2 if comeback else 1)
	var target: int = LEVELS[level_idx]["target"]
	if score >= target:
		win_pending = true


func show_toast(s: String) -> void:
	toast_text = s
	toast_t = 1.8


# =================================================================== physics
func closest_pt(a: Vector2, b: Vector2, p: Vector2) -> Vector2:
	var ab := b - a
	var l2 := ab.length_squared()
	if l2 < 0.0001:
		return a
	var k := clampf((p - a).dot(ab) / l2, 0.0, 1.0)
	return a + ab * k


# push the ball out of a segment and bounce it
func seg_hit(a: Vector2, b: Vector2, e: float) -> void:
	var cp := closest_pt(a, b, ball_p)
	var d := ball_p - cp
	var dist := d.length()
	if dist >= BALL_R:
		return
	var n := Vector2.UP
	if dist > 0.0001:
		n = d / dist
	ball_p = cp + n * BALL_R
	var vn := ball_v.dot(n)
	if vn < 0.0:
		ball_v -= (1.0 + e) * vn * n


func step_physics(dt: float) -> void:
	# flippers swing
	for item in flips:
		var f: Flip = item
		var prev := f.a
		var target := REST_A
		var sp := 14.0
		if f.down:
			target = UP_A
			sp = 24.0
		f.a = move_toward(f.a, target, sp * dt)
		f.da = (f.a - prev) / dt

	ball_v.y += GRAV * dt
	ball_v *= (1.0 - 0.03 * dt)
	if ball_v.length() > MAX_SPEED:
		ball_v = ball_v.normalized() * MAX_SPEED
	ball_p += ball_v * dt

	for item in segs:
		var s: Array = item
		seg_hit(s[0], s[1], float(s[2]))

	for item in bumpers:
		var b: Bumper = item
		var diff := ball_p - b.pos
		var dist := diff.length()
		var rr := BALL_R + b.r
		if dist < rr:
			var n := Vector2.UP
			if dist > 0.0001:
				n = diff / dist
			ball_p = b.pos + n * rr
			var sp := clampf(ball_v.length() * 0.6 + 420.0, 620.0, 1100.0)
			ball_v = n * sp
			b.pulse = 1.0
			add_score(100)
			play_sfx("bump")

	for item in flips:
		collide_flipper(item)


func collide_flipper(f: Flip) -> void:
	var tip := f.pivot + f.dir() * FLIP_LEN
	var cp := closest_pt(f.pivot, tip, ball_p)
	var s := (cp - f.pivot).length()
	var rad := lerpf(9.0, 5.5, s / FLIP_LEN)
	var diff := ball_p - cp
	var dist := diff.length()
	if dist >= BALL_R + rad:
		return
	var n := Vector2.UP
	if dist > 0.0001:
		n = diff / dist
	ball_p = cp + n * (BALL_R + rad)
	# velocity of the flipper surface at the contact point
	var surf := f.ddir() * s * f.da
	var rel := ball_v - surf
	var vn := rel.dot(n)
	if vn < 0.0:
		ball_v -= (1.0 + 0.35) * vn * n


# =================================================================== audio (generated, no files)
func setup_audio() -> void:
	add_sfx("bump", tone_bytes(520.0, 980.0, 0.09, 0.35))
	add_sfx("flip", noise_bytes(0.05, 0.25))
	add_sfx("launch", tone_bytes(200.0, 900.0, 0.3, 0.3))
	add_sfx("hurt", tone_bytes(420.0, 90.0, 0.4, 0.4))
	add_sfx("win", tone_bytes(523.0, 523.0, 0.12, 0.3) + tone_bytes(659.0, 659.0, 0.12, 0.3) \
		+ tone_bytes(784.0, 784.0, 0.12, 0.3) + tone_bytes(1047.0, 1047.0, 0.4, 0.3))


func add_sfx(n: String, bytes: PackedByteArray) -> void:
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = 22050
	w.stereo = false
	w.data = bytes
	var pl := AudioStreamPlayer.new()
	pl.stream = w
	add_child(pl)
	sfx_players[n] = pl


func tone_bytes(f0: float, f1: float, dur: float, vol: float) -> PackedByteArray:
	var rate := 22050
	var n := int(rate * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	var phase := 0.0
	for i in n:
		var k := float(i) / float(n)
		phase += TAU * lerpf(f0, f1, k) / float(rate)
		var env := (1.0 - k) * minf(1.0, k * 30.0)
		var s := (sin(phase) + 0.3 * sin(phase * 2.0)) * env * vol
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 32767.0))
	return data


func noise_bytes(dur: float, vol: float) -> PackedByteArray:
	var rate := 22050
	var n := int(rate * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var k := float(i) / float(n)
		var s := randf_range(-1.0, 1.0) * (1.0 - k) * vol
		data.encode_s16(i * 2, int(s * 32767.0))
	return data


func play_sfx(n: String) -> void:
	if not sfx_players.has(n):
		return
	var pl: AudioStreamPlayer = sfx_players[n]
	pl.pitch_scale = randf_range(0.95, 1.08)
	pl.play()


# =================================================================== drawing
func T(v: Vector2) -> Vector2:
	return v + OFF


func txt(s: String, pos: Vector2, size: int, col: Color = Color.WHITE, center: bool = false) -> void:
	if center:
		draw_string(font, Vector2(pos.x - 800.0, pos.y), s, HORIZONTAL_ALIGNMENT_CENTER, 1600.0, size, col)
	else:
		draw_string(font, pos, s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)


func fmt_num(n: int) -> String:
	var s := str(n)
	var out := ""
	var c := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		c += 1
		if c % 3 == 0 and i > 0:
			out = "," + out
	return out


func _draw() -> void:
	var cfg: Dictionary = LEVELS[level_idx]
	var bg: Color = cfg["bg"]
	draw_rect(Rect2(0, 0, W, H), bg)
	draw_table(cfg)

	if state == State.MENU:
		draw_menu(cfg)
		return
	draw_hud(cfg)

	if state == State.LEVEL_DONE:
		overlay("Table cleared!", "Press SPACE for the next table" if level_idx + 1 < LEVELS.size() else "Press SPACE to finish", cfg)
	elif state == State.FAILED:
		var target: int = cfg["target"]
		overlay("Out of balls", "%s / %s  -  press SPACE to try again" % [fmt_num(score), fmt_num(target)], cfg)
	elif state == State.WIN:
		overlay("You bounced back!", "All 3 tables cleared  -  press SPACE", cfg)


func overlay(title: String, sub: String, cfg: Dictionary) -> void:
	var acc: Color = cfg["color"]
	draw_rect(Rect2(0, 0, W, H), Color(0, 0, 0, 0.65))
	txt(title, Vector2(W * 0.5, 330), 64, acc, true)
	txt(sub, Vector2(W * 0.5, 400), 26, Color.WHITE, true)


func draw_table(cfg: Dictionary) -> void:
	var acc: Color = cfg["color"]
	var bg: Color = cfg["bg"]

	# playfield floor
	var poly := PackedVector2Array()
	for p in arc_pts:
		poly.append(T(p))
	poly.append(T(Vector2(500, 700)))
	poly.append(T(Vector2(0, 700)))
	draw_colored_polygon(poly, bg.darkened(0.5))

	# walls
	for item in segs:
		var s: Array = item
		draw_line(T(s[0]), T(s[1]), Color(1, 1, 1, 0.8), 3.0)

	# bumpers
	for item in bumpers:
		var b: Bumper = item
		draw_circle(T(b.pos), b.r + b.pulse * 5.0, acc.lerp(Color.WHITE, b.pulse * 0.6))

	# plunger
	var py := 662.0 + charge * 22.0
	draw_rect(Rect2(T(Vector2(LANE_X + 6.0, py)), Vector2(33, 9)), Color(0.75, 0.75, 0.8))

	# flippers
	for item in flips:
		var f: Flip = item
		var d := f.dir()
		var n := Vector2(-d.y, d.x)
		var p0 := T(f.pivot)
		var p1 := T(f.pivot + d * FLIP_LEN)
		draw_colored_polygon(PackedVector2Array([p0 + n * 9.0, p1 + n * 5.5, p1 - n * 5.5, p0 - n * 9.0]), Color.WHITE)
		draw_circle(p0, 9.0, Color.WHITE)
		draw_circle(p1, 5.5, Color.WHITE)

	# ball
	draw_circle(T(ball_p), BALL_R, Color.WHITE)


func draw_hud(cfg: Dictionary) -> void:
	var acc: Color = cfg["color"]
	var dim := Color(1, 1, 1, 0.6)
	var target: int = cfg["target"]

	txt("%s  (%d / %d)" % [cfg["name"], level_idx + 1, LEVELS.size()], Vector2(60, 80), 26, dim)

	txt("SCORE", Vector2(60, 200), 18, dim)
	txt(fmt_num(score), Vector2(60, 260), 56)
	var prog := clampf(float(score) / float(target), 0.0, 1.0)
	draw_rect(Rect2(60, 284, 260, 10), Color(1, 1, 1, 0.15))
	draw_rect(Rect2(60, 284, 260.0 * prog, 10), acc)
	txt("Target " + fmt_num(target), Vector2(60, 326), 20, dim)

	txt("BALLS", Vector2(60, 400), 18, dim)
	for i in 3:
		var c := Vector2(72.0 + i * 36.0, 430.0)
		if i < balls_left:
			draw_circle(c, 11.0, Color.WHITE)
		else:
			draw_arc(c, 10.0, 0.0, TAU, 20, Color(1, 1, 1, 0.3), 2.0)

	if comeback:
		txt("x2 BOUNCE BACK", Vector2(60, 500), 30, acc)

	txt("Flip: A / D or arrows", Vector2(930, 80), 20, dim)
	txt("Launch: hold SPACE", Vector2(930, 110), 20, dim)

	if toast_t > 0.0:
		var a := clampf(toast_t * 3.0, 0.0, 1.0)
		txt(toast_text, T(Vector2(227, 320)), 28, Color(1, 1, 1, a), true)


func draw_menu(cfg: Dictionary) -> void:
	var acc: Color = cfg["color"]
	draw_rect(Rect2(0, 0, W, H), Color(0, 0, 0, 0.55))
	txt("BOUNCE BACK PINBALL", Vector2(W * 0.5, 290), 80, acc, true)
	txt("Lose a ball. Bounce back stronger.", Vector2(W * 0.5, 350), 28, Color.WHITE, true)
	txt("Press SPACE to start", Vector2(W * 0.5, 480), 34, Color(1, 1, 1, 0.7 + 0.3 * sin(t * 4.0)), true)
	txt("Flip: A / D or arrows   -   Launch: hold SPACE", Vector2(W * 0.5, 540), 20, Color(1, 1, 1, 0.6), true)
